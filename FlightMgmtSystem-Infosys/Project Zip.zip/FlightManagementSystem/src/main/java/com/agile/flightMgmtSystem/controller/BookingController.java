package com.agile.flightMgmtSystem.controller;



import com.agile.flightMgmtSystem.bean.Flight;
import com.agile.flightMgmtSystem.bean.Passenger;
import com.agile.flightMgmtSystem.bean.Ticket;
import com.agile.flightMgmtSystem.bean.TicketPassengerEmbed;
import com.agile.flightMgmtSystem.service.BookingService;
import com.agile.flightMgmtSystem.service.FlightService;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class BookingController {
 
 @Autowired
 private BookingService bookingService;
 
 @Autowired
 private FlightService flightService;

 
 @GetMapping("/bookFlight")
 public String bookFlight(@RequestParam("flightNumber") Long flightNumber,
                          @RequestParam("carrierName") String carrierName,
                          @RequestParam("departure") String departure,
                          @RequestParam("arrival") String arrival,
                          @RequestParam("fare") Double fare,
                          @RequestParam("fromAirport") String fromAirport,
                          @RequestParam("toAirport") String toAirport,
                          @RequestParam("seatCapacity") Integer seatCapacity,
                          Model model) {
     model.addAttribute("flightNumber", flightNumber);
     model.addAttribute("carrierName", carrierName);
     model.addAttribute("departure", departure);
     model.addAttribute("arrival", arrival);
     model.addAttribute("fare", fare);
     model.addAttribute("fromAirport", fromAirport);
     model.addAttribute("toAirport", toAirport);
     model.addAttribute("seatCapacity", seatCapacity);
     return "bookFlight";
 }
 @PostMapping("/bookFlight")
 public String bookFlight(@RequestParam("flightNumber") Long flightNumber,
                          @RequestParam("carrierName") String carrierName,
                          @RequestParam("departure") String departure,
                          @RequestParam("arrival") String arrival,
                          @RequestParam("fare") Double fare,
                          @RequestParam("fromAirport") String fromAirport,
                          @RequestParam("toAirport") String toAirport,
                          Model model) {
     
     Flight flight = bookingService.findByFlightNumberAndCarrierName(flightNumber, carrierName);
     int seatCapacity = flight.getSeatCapacity();
     
     model.addAttribute("flightNumber", flightNumber);
     model.addAttribute("carrierName", carrierName);
     model.addAttribute("departure", departure);
     model.addAttribute("arrival", arrival);
     model.addAttribute("fare", fare);
     model.addAttribute("fromAirport", fromAirport);
     model.addAttribute("toAirport", toAirport);
     model.addAttribute("seatCapacity", seatCapacity);

     return "bookFlight";
 }
 
 @PostMapping("/bookingSuccess")
 public String confirmBooking(HttpServletRequest request,
                              @RequestParam("flightNumber") Long flightNumber,
                              @RequestParam("carrierName") String carrierName,
                              @RequestParam("routeId") Long routeId,
                              @RequestParam("totalAmount") Double totalAmount,
                              @RequestParam("ticketNumber") Long ticketNumber,
                              Model model) {

     List<Passenger> passengers = new ArrayList<>();
     int passengerCount = (request.getParameterMap().size() - 6) / 2; // Calculate passenger count dynamically

     for (int i = 1; i <= passengerCount; i++) {
         String passengerName = request.getParameter("passengerName" + i);
         String passengerDOB = request.getParameter("passengerDOB" + i);
         TicketPassengerEmbed embedId = new TicketPassengerEmbed(ticketNumber, (long) i);
         Passenger passenger = new Passenger(embedId, passengerName, passengerDOB, totalAmount / passengerCount);
         passengers.add(passenger);
     }

     // Create Ticket entity
     Ticket ticket = new Ticket(ticketNumber, routeId, flightNumber, carrierName, totalAmount);

     // Save booking information
     bookingService.saveBooking(ticket, passengers);

     model.addAttribute("ticket", ticket);
     model.addAttribute("passengers", passengers);

     return "bookingSuccess"; // Redirect to a success page
 }
}

