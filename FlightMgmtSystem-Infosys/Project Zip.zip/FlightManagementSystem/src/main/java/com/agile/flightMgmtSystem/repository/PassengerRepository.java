package com.agile.flightMgmtSystem.repository;

import com.agile.flightMgmtSystem.bean.Passenger;
import com.agile.flightMgmtSystem.bean.TicketPassengerEmbed;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PassengerRepository extends JpaRepository<Passenger, TicketPassengerEmbed> {
}