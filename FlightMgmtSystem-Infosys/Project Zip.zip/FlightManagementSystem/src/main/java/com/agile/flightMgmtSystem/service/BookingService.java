// FlightService.java
package com.agile.flightMgmtSystem.service;

import com.agile.flightMgmtSystem.bean.Flight;
import com.agile.flightMgmtSystem.bean.Passenger;
import com.agile.flightMgmtSystem.bean.Ticket;
import com.agile.flightMgmtSystem.repository.BookingRepository;
import com.agile.flightMgmtSystem.repository.PassengerRepository;
import com.agile.flightMgmtSystem.repository.TicketRepository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookingService {

    @Autowired
    private BookingRepository bookingRepository;
    
    @Autowired
    private TicketRepository ticketRepository;

    @Autowired
    private PassengerRepository passengerRepository;

    public Flight findByFlightNumberAndCarrierName(Long flightNumber, String carrierName) {
        return bookingRepository.findByFlightNumberAndCarrierName(flightNumber, carrierName);
    }

    public double calculateFare(int age, double baseFare) {
        if (age < 2) {
            return 0;
        } else if (age >= 2 && age <= 12) {
            return baseFare * 0.5; // 50% discount for children
        } else {
            return baseFare;
        }
    }
    
    public void saveBooking(Ticket ticket, List<Passenger> passengers) {
        ticketRepository.save(ticket);
        passengerRepository.saveAll(passengers);
    }
}
