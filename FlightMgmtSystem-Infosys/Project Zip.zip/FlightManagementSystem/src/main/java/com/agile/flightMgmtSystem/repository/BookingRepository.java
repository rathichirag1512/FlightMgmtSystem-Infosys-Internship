// FlightRepository.java
package com.agile.flightMgmtSystem.repository;

import com.agile.flightMgmtSystem.bean.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<Flight, Long> {
    Flight findByFlightNumberAndCarrierName(Long flightNumber, String carrierName);
}
