package com.agile.flightMgmtSystem.bean;

import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class TicketPassengerEmbed implements Serializable {
    private Long ticketNumber;
    private Long passengerId;

    public TicketPassengerEmbed() {
        super();
    }

    public TicketPassengerEmbed(Long ticketNumber, Long passengerId) {
        super();
        this.ticketNumber = ticketNumber;
        this.passengerId = passengerId;
    }

    // Getter and setter methods
    public Long getTicketNumber() {
        return ticketNumber;
    }

    public void setTicketNumber(Long ticketNumber) {
        this.ticketNumber = ticketNumber;
    }
    
    public Long getPassengerId() {
        return passengerId;
    }

    public void setPassengerId(Long passengerId) {
        this.passengerId = passengerId;
    }
}

