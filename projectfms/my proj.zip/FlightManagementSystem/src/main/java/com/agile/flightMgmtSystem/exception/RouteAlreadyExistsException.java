package com.agile.flightMgmtSystem.exception;

public class RouteAlreadyExistsException extends Exception {
    public RouteAlreadyExistsException(String message) {
        super(message);
    }
}
