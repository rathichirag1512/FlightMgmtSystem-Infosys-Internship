package com.agile.flightMgmtSystem.repository;

public interface CustomRouteRepository {
    Long generateRouteId();
}
