package com.agile.flightMgmtSystem.exception;

public class AirportNotFoundException extends Exception {
    public AirportNotFoundException(String message) {
        super(message);
    }
}
